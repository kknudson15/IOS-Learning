//Swift Structs
struct Town {
    let name : String
    var citizens : [String]
    var resources : [String : Int]
    
    init(townName : String, people : [String], stats: [String:Int]) {
        name = townName
        citizens = people
        resources = stats
    }
    
    func fortify() {
        print("Defenses increased!")
    }
}


var anotherTown = Town(townName: "KyleLand", people: ["Kyle", "Jack", "Bauer"], stats: ["coconuts" : 100])

print(anotherTown.name)
print(anotherTown.citizens)
print(anotherTown.resources)
anotherTown.fortify()
anotherTown.citizens.append("wilson")



//Swift Functions with output and return types
func greeting1(){
    print("Hello")
}

greeting1()

func greeting2(name: String){
    print("Hello \(name)")
}

greeting2(name: "Kyle")


func greeting3(name: String) -> Bool {
    if name == "Kyle" || name == "Jack Bauer" {
        return true
    } else {
        return false
    }
}

var doorShouldOpen = greeting3(name: "Kyle")
print(doorShouldOpen)




//Struct Challenge
// TODO: Define the struct
struct User {
  let name : String
  var email : String?
  var followers : Int
  var isActive : Bool
  
  init (name: String, email: String?, followers : Int, isActive : Bool){
    self.name = name
    self.email = email
    self.followers = followers
    self.isActive = isActive
  }
  
  func logStatus () {
    if self.isActive {
      print("\(self.name) is working hard")
    } else {
      print("\(self.name) has left earth")
    }
  }
}

// TODO: Initialise the struct
var newUser = User(name: "Richard", email: "jjjk@gmail.com", followers: 0, isActive: false)
newUser.logStatus()


// Diagnostic code - do not change this code
print("\nDiagnostic code (i.e., Challenge Hint):")
var musk = User(name: "Elon", email: "elon@tesla.com", followers: 2001, isActive: true)
musk.logStatus()
print("Contacting \(musk.name) on \(musk.email!) ...")
print("\(musk.name) has \(musk.followers) followers")
// sometime later
musk.isActive = false
musk.logStatus()


//Functions Challenge
//Create your function here:
func isOdd(n:Int) -> Bool {
  if n % 2 == 0 {
    return false
  } else {
    return true
  }
}


//Do not change the code below.
let testNumber = Int(readLine()!)!
let numberIsOdd = isOdd(n: testNumber)
print(numberIsOdd)
