//Function Work

func greeting(){
    print("hello")
}

greeting()
greeting()
greeting()
greeting()


func greeting1(){
    print("Hello")
    
    let myName = "Kyle"
    print(myName)
}

func greeting2(){
    print("Hey")
}

greeting1()





//Function Challenge Problem 1
//Step 1.  Click run to see the starting map and final map. It should look something like this:
//
//Starting map
//["🦊", "⬜️", "⬜️", "⬜️", "⬜️", "⬜️", "⬜️"]
//["⬜️", "⬜️", "⬜️", "⬜️", "⬜️", "⬜️", "⬜️"]
//["⬜️", "⬜️", "⬜️", "⬜️", "⬜️", "⬜️", "⬜️"]
//["⬜️", "⬜️", "⬜️", "⬜️", "⬜️", "⬜️", "⬜️"]
//["⬜️", "⬜️", "⬜️", "⬜️", "⬜️", "⬜️", "⬜️"]
//["⬜️", "⬜️", "⬜️", "⬜️", "🌽", "⬜️", "⬜️"]
//["⬜️", "⬜️", "⬜️", "⬜️", "⬜️", "⬜️", "⬜️"]
//Final map
//["🦊", "⬜️", "⬜️", "⬜️", "⬜️", "⬜️", "⬜️"]
//["⬜️", "⬜️", "⬜️", "⬜️", "⬜️", "⬜️", "⬜️"]
//["⬜️", "⬜️", "⬜️", "⬜️", "⬜️", "⬜️", "⬜️"]
//["⬜️", "⬜️", "⬜️", "⬜️", "⬜️", "⬜️", "⬜️"]
//["⬜️", "⬜️", "⬜️", "⬜️", "⬜️", "⬜️", "⬜️"]
//["⬜️", "⬜️", "⬜️", "⬜️", "🌽", "⬜️", "⬜️"]
//["⬜️", "⬜️", "⬜️", "⬜️", "⬜️", "⬜️", "⬜️"]
//
//Step 2. Use a combination of these four functions
//up()
//down()
//left()
//right()
//to navigate the 🦊to the 🌽.

//Code:
//print("Starting map")
//start()
////Write your code here:
//down()
//down()
//down()
//down()
//down()
//right()
//right()
//right()
//right()


//Swift function with input
//func myfunc(parameter: DataType){
    //Do Something with the input
//}


var myAge = 27
myAge = 28

//Example function
func greeting3(whoToGreet : String){
    print("Hello \(whoToGreet)")
}

greeting3(whoToGreet: "Kyle")

//Function 2 Challenge
//In this coding exercise, you're going to create a simple calculator. You will need to create 4
//functions so that when you run the code, the correct answers are printed in the console. Once
//you've completed your functions with inputs, you can comment out the lines 6-9 and run the code to
//check.

func calculator() {
  let a = Int(readLine()!)! //First input
  let b = Int(readLine()!)! //Second input
  
  add(n1: a, n2: b)
  subtract(n1: a, n2: b)
  multiply(n1: a, n2: b)
  divide(n1: a, n2: b)
  
}

//Write your code below this line to make the above function calls work.

func add(n1: Int, n2: Int){
  print(n1 + n2)
}

func subtract(n1: Int, n2: Int){
  print(n1 - n2)
}

func multiply(n1: Int, n2: Int){
  print(n1 * n2)
}

func divide(n1: Int, n2: Int){
  
  let num2 = Double(n1) / Double(n2)
  print(num2)
}

calculator()



