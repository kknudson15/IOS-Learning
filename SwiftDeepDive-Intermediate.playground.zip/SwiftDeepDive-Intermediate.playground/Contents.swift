//Love Calculator Challenge
//If-Else Control flow
func loveCalculator(){
    let loveScore = Int.random(in: 0 ... 100)
    
    if loveScore > 80 {
        print("You love each other like Kanye loves Kanye.")
    } else if loveScore > 40 {
        print("You go together like Coke and Mentos")
    } else {
        print("You'll be forever alone.")
    }
}

loveCalculator()


//if else challenge
var aYear =  Int(readLine()!)!

func isLeap(year: Int) {
  if year % 4 == 0 {
    if year % 100 == 0 {
        if year % 400 == 0 {
            print ("YES")}
            else{
                print("NO")
            }
    }else{
         print("YES")}
    }
  else{
    print("NO")}
  
  
  
}
isLeap(year: aYear)


//Switch Statement
func loveCalculator2(){
    let loveScore = Int.random(in: 0 ... 100)
    
    switch loveScore {
    case 81...100:
         print("You love each other like Kanye loves Kanye.")
    case 40..<81:
         print("You go together like Coke and Mentos")
    default:
         print("You'll be forever alone.")
    }
}

loveCalculator2()


//Switch Statement Challenge
var aNumber =  Int(readLine()!)!

func dayOfTheWeek(day: Int) {
switch day{
  case 1:
    print("Monday")
  case 2:
    print("Tuesday")
  case 3:
    print("Wednesday")
  case 4:
    print("Thursday")
  case 5:
    print("Friday")
  case 6:
    print("Saturday")
  case 7:
    print("Sunday")
  default:
    print("Error")
}
}
dayOfTheWeek(day: aNumber)


//Dictionaries
//Example Dictionary
var dict : [String : Int] = ["Angela" : 771234567, "Philip" : 774345395]

print(dict["Angela"]!)


//Don't change this
var stockTickers: [String: String] = ["APPL" : "Apple Inc","HOG": "Harley-Davidson Inc",
                                     "BOOM": "Dynamic Materials", "HEINY": "Heineken",
                                     "BEN": "Franklin Resources Inc"]

//Write your code here.
stockTickers["WORK"] = "Slack Technologies Inc"
stockTickers["BOOM"] = "DMC Global Inc"

  
 
 
 
 
 
 
 
 
 
 
 
 
 
 // Don't modify this
 print(stockTickers["WORK"]!)
 print(stockTickers["BOOM"]!)


//Optionals
//option 1
//var player1Username: String = nil

//option 2
var player1Username: String? = nil

player1Username = "jackbaueris"

if player1Username != nil {
    print(player1Username!)
}


//Optional Challenge
var studentsAndScores = ["Amy": Int(readLine()!)!, "James": Int(readLine()!)!, "Helen": Int(readLine()!)!]

func highestScore(scores: [String: Int]) {
    let max_value = scores.values.max()
    print(max_value!)
}
highestScore(scores: studentsAndScores)





